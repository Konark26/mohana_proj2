// import ApplicationDetails from "../components/ApplicationDetails";
// import VolumePatterns from "../components/VolumePatterns";
// import SalesSeason from "../components/SalesSeason/SalesSeason";
// import PeakSalesCertification from "../components/PeakSalesCertification";
// import HolidayReadiness from "../components/HolidayReadiness/HolidayReadiness";
// import PeakSalesCapacity from "../components/PeakSalesCapacity";
// import TrendAnalysis from "../components/TrendAnalysis";
import Home from "../components/Home/Home";
// import GroupDetails from "../components/GroupDetails/GroupDetails";

const routes = [
    {
        path: "/relove/home",
        exact: true,
        component: Home
    },
    {
        path: "/pitstop/prod-volume-patterns",
        exact: true,
        component: Home
    },
    {
        path: "/pitstop/sales-season",
        exact: true,
        component: Home
    },
    {
        path: "/pitstop/peak-sales/certification",
        exact: true,
        component: Home
    },
    {
        path: "/pitstop/holiday-readiness",
        exact: true,
        component: Home
    },
    {
        path: "/pitstop/peak-sales/capacity-assesment",
        exact: true,
        component: Home
    },
    {
        path: "/pitstop/trend-analysis",
        exact: true,
        component: Home
    },
    {
        path: "/pitstop/application-details",
        exact: true,
        component: Home
    },
    {
        path: "/pitstop/group-details",
        exact: true,
        component: Home
    },
]

export default routes;