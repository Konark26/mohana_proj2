const drawerWidth = 280;

module.exports = {
    drawerWidth
}