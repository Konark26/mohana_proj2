const baseAPIURI = "/relove/api/v1";
const baseURI = "/relove";

const homeURI = baseURI + "/home";
const loginURI = baseURI + "/security/user";
const logoutURI = baseURI + "/logout";
const TodoListURI = baseAPIURI + "/todos";
const AddTodoListURI = baseAPIURI + "/todos/add";
const DeleteTodoListURI = baseAPIURI + "/todos/delete/";


module.exports = {
    homeURI,
    loginURI,
    logoutURI,
    TodoListURI,
    AddTodoListURI,
    DeleteTodoListURI
}