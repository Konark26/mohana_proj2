const CANCEL = "Cancel"

module.exports = {
    CANCEL
}