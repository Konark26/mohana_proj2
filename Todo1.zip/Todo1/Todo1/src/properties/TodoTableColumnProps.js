const columns = [
    {
        id: "serialNumber",
        label: "S. No",
        minWidth: 30,
        align: "left",
        fontWeight: "bold"
    },
    {
        id: "todo",
        label: "Todo",
        minWidth: 30,
        align: "left",
        fontWeight: "bold"
    },
    {
        id: "description",
        label: "Description",
        minWidth: 50,
        align: "left",
        fontWeight: "bold"
    },
    {
        id: "priority",
        label: "Priority",
        minWidth: 30,
        align: "left",
        fontWeight: "bold"
    },
    {
        id: "actions",
        label: "Actions",
        minWidth: 40,
        align: "left",
        fontWeight: "bold"
    }
];

module.exports = {
    columns
}