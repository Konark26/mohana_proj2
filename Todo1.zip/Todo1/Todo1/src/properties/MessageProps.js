const APP_TITLE = "Pitstop";
const FOOTER_MSG = "by Mohana Priya. All rights reserved.";

const SIGN_IN = "Sign In";
const SIGN_OUT = "Sign Out";


const SUCCESS_TITLE = "Success";

module.exports = {
	APP_TITLE,
	FOOTER_MSG,
    SIGN_IN,
    SIGN_OUT,
    SUCCESS_TITLE
}