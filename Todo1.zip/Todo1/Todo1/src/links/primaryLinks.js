import DesktopWindowsIcon from '@material-ui/icons/DesktopWindows';
import FilterNoneIcon from '@material-ui/icons/FilterNone';
import EqualizerIcon from '@material-ui/icons/Equalizer';
import ReceiptIcon from '@material-ui/icons/Receipt';
import CardMembershipIcon from '@material-ui/icons/CardMembership';
import DashboardIcon from '@material-ui/icons/Dashboard';
import TrendingUpIcon from '@material-ui/icons/TrendingUp';
import FilterIcon from '@material-ui/icons/Filter';
import HomeIcon from '@material-ui/icons/Home';

const primaryLinks = [
    {
        key: 1,
        title: "Home",
        to: "/pitstop/home",
        icon: (<HomeIcon />),
        iconSelected: (<HomeIcon style={{ fill: "#3f51b5"}}/>)
    },
    {
        key: 2,
        title: "Volume Patterns",
        to: "/pitstop/prod-volume-patterns",
        icon: (<EqualizerIcon />),
        iconSelected: (<EqualizerIcon style={{ fill: "#3f51b5"}}/>)
    },
    {
        key: 3,
        title: "Sales Season",
        to: "/pitstop/sales-season",
        icon: (<ReceiptIcon />),
        iconSelected: (<ReceiptIcon style={{ fill: "#3f51b5"}}/>)
    },
    {
        key: 4,
        title: "Peak Sales Certification",
        to: "/pitstop/peak-sales/certification",
        icon: (<CardMembershipIcon />),
        iconSelected: (<CardMembershipIcon style={{ fill: "#3f51b5"}}/>)
    },
    {
        key: 5,
        title: "Holiday Readiness",
        to: "/pitstop/holiday-readiness",
        icon: (<DashboardIcon />),
        iconSelected: (<DashboardIcon style={{ fill: "#3f51b5"}}/>)
    },
    // {
    //     key: 6,
    //     title: "Peak Sales Capacity",
    //     to: "/pitstop/peak-sales/capacity-assesment",
    //     icon: (<FilterIcon />),
    //     iconSelected: (<FilterIcon style={{ fill: "#3f51b5"}}/>)
    // },
    // {
    //     key: 7,
    //     title: "Trend Analysis",
    //     to: "/pitstop/trend-analysis",
    //     icon: (<TrendingUpIcon />),
    //     iconSelected: (<TrendingUpIcon style={{ fill: "#3f51b5"}}/>)
    // },
    {
        key: 8,
        title: "Application Details",
        to: "/pitstop/application-details",
        icon: (<DesktopWindowsIcon />),
        iconSelected: (<DesktopWindowsIcon style={{ fill: "#3f51b5"}}/>)
    },
    {
        key: 8,
        title: "Group Details",
        to: "/pitstop/group-details",
        icon: (<FilterNoneIcon />),
        iconSelected: (<FilterNoneIcon style={{ fill: "#3f51b5"}}/>)
    },
]

export default primaryLinks;