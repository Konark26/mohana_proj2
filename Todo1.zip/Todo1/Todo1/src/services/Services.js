import axios from "axios";

export async function fetch(uri, handleSuccess, handleFailure) {
    await axios
    .get(uri)
    .then(response => {
        handleSuccess(response);
    })
    .catch(error => {
       handleFailure(error);
    });
}

export async function fetchMulti(handleSuccess, handleFailure, ...uri) {
    const requestOne = axios.get(uri[0]);
    const requestTwo = axios.get(uri[1]);

    await axios
        .all([requestOne, requestTwo])
        .then(axios.spread((...responses) => {
            handleSuccess(responses[0]);
        }))
        .catch(axios.spread((...errors) => {
            handleFailure(errors[0]);
        }));
}

export async function add(uri, payload, handleSuccess, handleFailure) {
    await axios
    .post(uri, payload)
    .then(response => {
        handleSuccess(response);
    })
    .catch(error => {
          handleFailure(error);
    });
}

export async function update(uri, payload, handleSuccess, handleFailure) {
    await axios
    .put(uri, payload)
    .then(response => {
        handleSuccess(response);
    })
    .catch(error => {
          handleFailure(error);
    });
}