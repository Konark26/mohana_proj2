import React from "react";
import Modal from "@material-ui/core/Modal";
import "../App.css";
import { SUCCESS_TITLE } from "../../properties/MessageProps";
import { Typography } from "@material-ui/core";
import { Button } from "@material-ui/core";

export default function SuccessMessageModal(props) {
	return (
		<React.Fragment>
			<Modal
				open={props.open}
				aria-labelledby="simple-modal-title"
				aria-describedby="simple-modal-description"
			>
				<div className="modal-paper" align="center">
					<div>
						<Typography variant="h5" gutterBottom>
							{SUCCESS_TITLE}
						</Typography>
						<Typography variant="subtitle1">{props.message}</Typography>
					</div>
                    <div>
                        <Button color="primary" variant="contained" onClick={props.handleClose}>Close</Button>
                    </div>
				</div>
			</Modal>
		</React.Fragment>
	);
}
