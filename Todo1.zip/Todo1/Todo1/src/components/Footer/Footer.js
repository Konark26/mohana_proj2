import React from "react";
import CssBaseline from "@material-ui/core/CssBaseline";
import Typography from "@material-ui/core/Typography";
import Container from "@material-ui/core/Container";
import "../App.css";
import { FOOTER_MSG } from "../../properties/MessageProps";

export default function Footer() {
  
  return (
    <React.Fragment>
      <div>
        <CssBaseline />
        <footer className="footer">
          <Container align="center">
            <Typography variant="body1">
              © {new Date().getFullYear()} {FOOTER_MSG}
            </Typography>
          </Container>
        </footer>
      </div>
    </React.Fragment>
  );
}
