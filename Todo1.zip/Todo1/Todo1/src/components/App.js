// import logo from './logo.svg';
import React, { useState } from 'react'
import './App.css';
import Footer from "./Footer/Footer";
import Header from "./Header/Header";
import Body from "./Body/Body";
import TodoList from "./Context/TodoList";

function App() {
    let [open, setOpen] = useState(true);

    let handleDrawerOpen = () => {
      setOpen(!open);
    };
    return (
        <div className="App">
            <Header open={open} handleDrawerOpen={handleDrawerOpen} />
          {/* <AppHierarchy > */}
            <TodoList>
              <Body open={open} />
            </TodoList>
          {/* </AppHierarchy> */}
        <Footer />
        </div>
    );
}

export default App;
