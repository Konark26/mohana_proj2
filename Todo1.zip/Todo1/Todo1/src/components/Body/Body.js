import React from "react";
import classNames from "classnames";
import { Route, Switch } from 'react-router-dom';
import routes from "../../routes/routes";
import SideBar from "./SideBar";
import { makeStyles } from '@material-ui/core/styles';
import { drawerWidth } from "../../properties/GlobalConstants";

export default function Body(props) {

    let {
        open
    } = props;
    
    const useStyles = makeStyles (theme => ({
        content: {
            flexGrow: 1,
            padding: theme.spacing(3),
            transition: theme.transitions.create('margin', {
              easing: theme.transitions.easing.sharp,
              duration: theme.transitions.duration.leavingScreen,
            }),
            marginLeft: theme.spacing(7) + 1,
        },
        contentShift: {
            transition: theme.transitions.create('margin', {
              easing: theme.transitions.easing.easeOut,
              duration: theme.transitions.duration.enteringScreen,
            }),
            marginLeft: drawerWidth,
        },
    }));

    const classes = useStyles();
    
    return (
        <React.Fragment>
            {/* <SideBar open={open} /> */}
            <div className={classNames(classes.content, {
                [classes.contentShift]: open, })}>
                <Switch>
                    {routes.map((route, index) => (
                        <Route exact={route.exact} path={route.path} key={index} component={route.component} />
                    ))}
                </Switch>
            </div>
        </React.Fragment>
    )
}