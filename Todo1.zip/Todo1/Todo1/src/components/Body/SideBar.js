import React, { useEffect, useState, useContext } from "react";
import classNames from "classnames";
import { makeStyles } from '@material-ui/core/styles';
import { Link } from "react-router-dom";
import List from "@material-ui/core/List";
import ListItem from "@material-ui/core/ListItem";
import ListItemIcon from "@material-ui/core/ListItemIcon";
import ListItemText from "@material-ui/core/ListItemText";
import Tooltip from "@material-ui/core/Tooltip";
import Drawer from "@material-ui/core/Drawer";
import { drawerWidth } from "../../properties/GlobalConstants";
import primaryLinks from "../../links/primaryLinks";
// import privateLinks from "../../links/privateLinks";
import { useLocation } from 'react-router-dom';
// import { UserContext } from "../Context/UserDetails";
// import {SIGN_IN_MESSAGE} from "../../properties/MessageProps"
// import LoginModal from "../Util/LoginModal"
import "../App.css";

export default function SideBar(props) {

    const location = useLocation();
    // const  user = useContext(UserContext);
    // const [openLogin, setOpenLogin] = useState(false);
    // const [toURI, setToURI] = useState("");
    const [chosen, setChosen] = useState();
    
    // const handleLogin = () => {
    //     window.location.assign(toURI);
    // }
        
    // const handleNoThanks = () => {
    //     setOpenLogin(false);
    // }

    useEffect(() => {

        if(location.pathname !== "/pitstop/") {
            let activeLink = primaryLinks.find(link => {
                return link.to === location.pathname
             });
     
             setChosen(activeLink.key);
        }
    }, [location.pathname]);

    const handleEvent = (activeLink) => {
        setChosen(activeLink.key);
    }

    const handleTo = (activeLink) => {
        return activeLink.to;
    }

    const useStyles = makeStyles (theme => ({
        drawer: {
            width: drawerWidth,
            flexShrink: 0,
            whiteSpace: "nowrap"
        },
        drawerOpen: {
            width: drawerWidth,
            height: `calc(100% - 41px)`,
            transition: theme.transitions.create("width", {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.enteringScreen
            })
        },
        drawerClose: {
            transition: theme.transitions.create("width", {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
            }),
            overflowX: "hidden",
            width: theme.spacing(7) + 1,
            height: `calc(100% - 41px)`,
            [theme.breakpoints.up("sm")]: {
            width: theme.spacing(9) + 1
            }
        },
        toolbar: {
            display: "flex",
            alignItems: "center",
            marginTop: theme.spacing(1),
            justifyContent: "flex-end",
            padding: "0 8px",
            ...theme.mixins.toolbar
        },
    }));

    const {
        open
    } = props;

    const classes = useStyles();

    return (
        <React.Fragment>
            {/* <LoginModal open={openLogin} message={SIGN_IN_MESSAGE} handleClose={handleNoThanks} handleYes={handleLogin} /> */}
            <Drawer variant="permanent"
                className={classNames(classes.drawer, {
                [classes.drawerOpen]: open,
                [classes.drawerClose]: !open
                })}
                classes={{
                paper: classNames({
                    [classes.drawerOpen]: open,
                    [classes.drawerClose]: !open
                })
                }}
                open={open}>
                <div className={classes.toolbar} />
                
                {primaryLinks.map((primaryLink, index) => (
                    <List className="sidebar list" key={index}>
                        <ListItem draggable="false" className="sidebar link" 
                            component={Link} onClick={() => handleEvent(primaryLink)}
                            to={() => handleTo(primaryLink)} id={primaryLink.key}>
                            <Tooltip title={primaryLink.title} placement="right">
                                <ListItemIcon>
                                    { primaryLink.key === chosen ? primaryLink.iconSelected :primaryLink.icon }
                                </ListItemIcon>
                            </Tooltip>
                            <ListItemText className={ primaryLink.key === chosen ? "sidebar text active" : "sidebar text"}>
                                {primaryLink.title}
                            </ListItemText>
                        </ListItem>
                    </List>
                ))}
                
            </Drawer>
        </React.Fragment>
    )
}