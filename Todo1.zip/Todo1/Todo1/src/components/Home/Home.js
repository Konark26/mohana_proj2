import React, { useState, useContext, useEffect } from "react";
import "../App.css"
import Typography from "@material-ui/core/Typography";
import Paper from "@material-ui/core/Paper";
import Table from "@material-ui/core/Table";
import TableContainer from "@material-ui/core/TableContainer";
import TableBody from "@material-ui/core/TableBody";
import TableCell from "@material-ui/core/TableCell";
import TableRow from "@material-ui/core/TableRow";
import TableHead from "@material-ui/core/TableHead";
import classNames from "classnames";
import { TodoListContext } from "../Context/TodoList";
import { columns } from "../../properties/TodoTableColumnProps";
import Button from "@material-ui/core/Button";
import AddIcon from "@material-ui/icons/Add";
import CreateTodo from "./CreateTodo";
import LoadingBackdrop from "../Utils/LoadingBackdrop";
import { TodoListURI } from "../../properties/ServiceURIProps";
import { fetch } from "../../services/Services";
import { Delete } from "@material-ui/icons";
import { IconButton } from "@material-ui/core";
import axios from "axios";
import { DeleteTodoListURI } from "../../properties/ServiceURIProps";

export default function Home(props) {
    let todoList = useContext(TodoListContext);
    const [todos,setTodos] = useState(todoList.todoList);
    const [addOpen, setAddOpen] = useState(false);

    const handleAddOpen = () => {
        setAddOpen(!addOpen);
    };
    const handleSearchTodoListSuccess = (response) => {
        setTodos(response.data);
        console.log(response.data)
    }

    const handleSearchTodoListFailure = (error) => {
        console.log(error);
    }
    const [rows,setRows]=useState(0);
        
	useEffect(() => {
        fetch(TodoListURI, handleSearchTodoListSuccess, handleSearchTodoListFailure)
    },[rows]);

    const handleDelete =(id)=>{
        axios.delete(DeleteTodoListURI+id);
        setRows(rows-1);
    }
    return (
        <React.Fragment>
            <div className="content-wrap">
                {todos === undefined || todos.length === undefined ? (<LoadingBackdrop />) :
                    (
                        <div>
                            <Typography variant="h6" align="center" gutterBottom>
                                Todo Details
                            </Typography>
                            <Button
                                color="primary"
                                variant="contained"
                                className="form button"
                                onClick={handleAddOpen}
                                startIcon={<AddIcon />}>
                                Create Todo
                            </Button>
                            <Paper className="result content">
                                <TableContainer className="result container">
                                    <Table stickyHeader size="small" aria-label="sticky table" className="result table" id="appOverallPeak">
                                        <TableHead>
                                            <TableRow>
                                                {columns.map(column => (
                                                    <TableCell
                                                        key={column.id}
                                                        align={column.align}
                                                        style={{ width: column.minWidth, fontWeight: column.fontWeight }}
                                                        className="result table-header">
                                                        {column.label}
                                                    </TableCell>
                                                ))}
                                            </TableRow>
                                        </TableHead>
                                        <TableBody>
                                            {todos.map((todo, index) => (
                                                <TableRow>
                                                    <TableCell align="left">{index + 1}</TableCell>
                                                    <TableCell align="left">{todo.todoName}</TableCell>
                                                    <TableCell align="left">{todo.todoDescription}</TableCell>
                                                    <TableCell align="left">{todo.todoPriority}</TableCell>
                                                    <TableCell align="left">
                                                        <IconButton onClick={()=>handleDelete(todo.todoId)}>
                                                            <Delete/>
                                                        </IconButton>
                                                    </TableCell>
                                                </TableRow>
                                            ))}

                                        </TableBody>
                                    </Table>
                                </TableContainer>
                            </Paper>
                            <CreateTodo open={addOpen} handleOpen={handleAddOpen} rows={rows} setRows={setRows}/>
                        </div>
                    )}
            </div>
        </React.Fragment>)
}