import React, { useContext, useState, useEffect } from "react";
import Dialog from "@material-ui/core/Dialog";
import DialogContent from "@material-ui/core/DialogContent";
import DialogTitle from "@material-ui/core/DialogTitle";
import "../App.css";
import { Formik, Form } from "formik";
import { makeStyles } from "@material-ui/core/styles";
import { Typography, Divider, TextField, Select } from "@material-ui/core";
import Button from "@material-ui/core/Button";
import { add } from "../../services/Services";
import { AddTodoListURI } from "../../properties/ServiceURIProps";
import InputLabel from "@material-ui/core/InputLabel";
import { FormControl } from "@material-ui/core";
import classNames from "classnames";
import MenuItem from "@material-ui/core/MenuItem";
import SuccessMessageModal from "../Utils/SuccessMessageModal";

export default function CreateTodo(props) {

	const {
		open,
		handleOpen,
        rows,
        setRows
	} = props;

	const initialValues = {
        todoId:"",
        todoName:"",
        todoDescription:"",
        todoPriority:""
	};

    const[openSuccess,setOpenSucess]= useState(false);

    const useStyles = makeStyles((theme) => ({
		stepper: {
			padding: theme.spacing(3, 0, 5),
		},
		buttons: {
			display: "flex",
			justifyContent: "flex-end",
		},
		button: {
			marginTop: theme.spacing(3),
			marginLeft: theme.spacing(1),
		},
		wrapper: {
			margin: theme.spacing(1),
			position: "relative",
		},
		buttonProgress: {
			position: "absolute",
			top: "50%",
			left: "50%",
		},
	}));

    const handleSubmitSuccess = (response) => {
		if (response.status === 200) {
            console.log("success");
            setOpenSucess(true)
            setRows(rows+1)
            // handleOpen();
		}
	};

	const handleSubmitFailure = (error) => {
        console.log("faliure");
        handleOpen();
	};

	const classes = useStyles();
	const handleSubmit = (values, actions) => {
		add(AddTodoListURI, values, handleSubmitSuccess, handleSubmitFailure);
	};
    const handleClose = () => {
        setOpenSucess(false);
        handleOpen();
	};

	return (
		<React.Fragment>
			<Dialog
				disableBackdropClick
				disableEscapeKeyDown
				fullWidth={true}
				maxWidth="lg"
				open={open}
				onClose={handleOpen}
				aria-labelledby="form-dialog-title">

				<DialogTitle id="form-dialog-title"> Create Todo List</DialogTitle>

				<DialogContent>
					<React.Fragment>
							<Formik
								initialValues={initialValues}
								// validationSchema={currentValidationSchema}
								onSubmit={(initialValues, values) =>
									handleSubmit(initialValues, values)
								}
                                >
								{({
									values,
									touched,
									errors,
									handleChange,
									handleBlur,
									setFieldValue,
									isSubmitting,
								}) => (
									<Form>
										{/* <div className={classes.buttons}> */}
											<div className="form group basic">
                                            <TextField
                                                label="TodoId"
                                                id="todoId"
                                                variant="outlined"
                                                className="form formControl app"
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                required={true}
                                                value={values.todoId}
                                                error={touched.todoId && errors.todoId ? true : false}
                                                helperText={touched.todoId && errors.todoId}
                                            />
                                            <TextField
                                                label="TodoName"
                                                id="todoName"
                                                variant="outlined"
                                                className="form formControl app"
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                required={true}
                                                value={values.todoName}
                                                error={touched.todoName && errors.todoName ? true : false}
                                                helperText={touched.todoName && errors.todoName}
                                            />
                                            <TextField
                                                label="TodoDescription"
                                                id="todoDescription"
                                                variant="outlined"
                                                className="form formControl app"
                                                onChange={handleChange}
                                                onBlur={handleBlur}
                                                required={true}
                                                value={values.todoDescription}
                                                error={touched.todoDescription && errors.todoDescription ? true : false}
                                                helperText={touched.todoDescription && errors.todoDescription}
                                            />
                                                        <FormControl 
                                                            // fullWidth 
                                                            variant="outlined"  
                                                            className={classNames("form formControl app", "form textfield")}
                                                            MenuProps={{
                                                                getContentAnchorEl: null,
                                                                anchorOrigin: {
                                                                    vertical: "bottom",
                                                                    horizontal: "left",
                                                                },
                                                            }}
                                                            name="todoPriority"
                                                            label="TodoPriority"
                                                            id="todoPriority"
                                                            required={true}
                                                            >
                                                            <InputLabel id="demo-simple-select-label">Priority</InputLabel>
                                                            <Select
                                                                labelId="demo-simple-select-label"
                                                                id="demo-simple-select"
                                                                value={values.todoPriority}
                                                                name="todoPriority"
                                                                label="TodoPriority"
                                                                id="todoPriority"
                                                                onChange={handleChange}
                                                                onBlur={handleBlur}
                                                            >
                                                                <MenuItem value="High">High</MenuItem>
                                                                <MenuItem value="Medium">Medium</MenuItem>
                                                                <MenuItem value="Low">Low</MenuItem>
                                                            </Select>
                                                            </FormControl>
											</div>
                                            <div className={classes.buttons}>
                                            <Button disabled={isSubmitting} type="submit"
													variant="contained" color="primary" className={classes.button}>
													Submit
												</Button>
                                                </div>
										{/* </div> */}
									</Form>
								)}
							</Formik>
						</React.Fragment>
						{/* {isSubmitting &&
							<LoadingBackdrop open={isSubmitting} /> &&
							<ProcessingMessageModal open={isSubmitting} message={PEAK_TEST_PROCESSING_SUCCESS} />
						} */}
						{/* {openError && <ErrorMessageModal open={openError} message={errorMessage} />} */}
						<SuccessMessageModal open={openSuccess} message={"The todo has been created"} handleClose={handleClose}/>
				</DialogContent>
			</Dialog>
		</React.Fragment>
	)
}