import React, { useContext } from "react";
import classNames from "classnames";
import { makeStyles } from '@material-ui/core/styles';
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import IconButton from "@material-ui/core/IconButton";
import MenuIcon from "@material-ui/icons/Menu";
// import lowesLogo from "../../images/Loweslogo.png";
// import pitstopLogo from "../../images/pitstop-logo.png";
// import { UserContext } from "../Context/UserDetails";
// import Logout from "./Logout";
import "../App.css";
// import { drawerWidth } from "../../properties/GlobalConstants";
// import Login from "./Login";

export default function Header(props) {
    const drawerWidth = 280;
    const useStyles = makeStyles(theme => ({
        appBar: {
            zIndex: theme.zIndex.drawer + 1
        },
        appBarShift: {
            marginLeft: drawerWidth,
            width: `calc(100% - ${drawerWidth}px)`,
            transition: theme.transitions.create(["width", "margin"], {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen
            })
        },
        menuButtonIconClosed: {
            transition: theme.transitions.create(["transform"], {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.leavingScreen
            }),
            transform: "rotate(0deg)"
        },
        menuButtonIconOpen: {
            transition: theme.transitions.create(["transform"], {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.leavingScreen
            }),
            transform: "rotate(180deg)"
        },
    }));

    const classes = useStyles();

    const {
        open,
        handleDrawerOpen
    } = props;

    // let user = useContext(UserContext);
    // let authButton;

    // if (user.loggedIn) {
    //     let userName = String(user.info.userName).split(/,|-/);
    //     let displayName = userName[1] + " " + userName[0];
    //     authButton = <Logout displayName={displayName} />;
    // } else {
    //     authButton = <Login header={true} />
    // }

    return (
        <React.Fragment>
            <div className="noprint">
                <div className="header root">
                    <AppBar className={classNames("header appBar", classes.appBar)}
                        position="fixed">
                        <Toolbar disableGutters={true}>
                            {/* {user.loggedIn && */}
                                <IconButton color="inherit" aria-label="Open drawer"
                                    onClick={handleDrawerOpen} className={classes.menuButton}>
                                    <MenuIcon classes={{
                                        root: open
                                            ? classes.menuButtonIconOpen
                                            : classes.menuButtonIconClosed
                                    }} />
                                </IconButton>
                                {/* } */}
                            <div className="header card" align="left">
                                {/* <img
                                    src={pitstopLogo}
                                    width="100px"
                                    alt="Pitstop Logo"
                                    draggable="false" /> */}
                            </div>
                            <div className="header card" align="left">
                                {/* <img
                                    src={lowesLogo}
                                    width="100px"
                                    alt="Lowes Logo"
                                    draggable="false" /> */}
                            </div>
                            {/* {authButton} */}
                        </Toolbar>
                    </AppBar>
                </div>
            </div>
        </React.Fragment>
    );
}