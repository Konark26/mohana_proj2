import React, { useState, useEffect } from "react";
import { fetch } from "../../services/Services";
import { TodoListURI } from "../../properties/ServiceURIProps";

export const TodoListContext = React.createContext({});

const TodoList = ({ children }) => {
    let [todoList, setTodoList] = useState({});

    useEffect(() => {
        fetch(TodoListURI, handleSearchTodoListSuccess, handleSearchTodoListFailure)
    }, []);
    
    const handleSearchTodoListSuccess = (response) => {
        setTodoList(response.data);
        console.log(response.data)
    }
    
    const handleSearchTodoListFailure = (error) => {
        console.log(error);
    }

    return (
        <TodoListContext.Provider value={{todoList, setTodoList}}>
            {children}
        </TodoListContext.Provider>
    );
};

export default TodoList;