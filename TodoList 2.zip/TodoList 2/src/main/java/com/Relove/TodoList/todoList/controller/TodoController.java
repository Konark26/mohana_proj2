package com.Relove.TodoList.todoList.controller;

import com.Relove.TodoList.todoList.model.Todo;
import com.Relove.TodoList.todoList.service.TodoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;
import java.util.Optional;

@RestController
@CrossOrigin
@RequestMapping(value = "/relove/api/v1", produces = MediaType.APPLICATION_JSON_VALUE)
public class TodoController {
	@Autowired
	TodoService todoService;

	@RequestMapping(value = "/todos", method = RequestMethod.GET)
	public List<Todo> getTodos(){

		return todoService.getAllTodos();
	}

	@RequestMapping(value="/todos/add",method=RequestMethod.POST)
	public List<Todo> addTodo(@RequestBody Todo newtodo){
		System.out.println("Adding new todo");
		System.out.println (newtodo);
		todoService.addTodo(newtodo);
		return todoService.getAllTodos();
	}

	@RequestMapping(value="/todos/delete/{todoid}",method = RequestMethod.DELETE)
	public void deleteTodo(@PathVariable Integer todoid){
		System.out.println("deleting the todo");
		todoService.deleteTodo(todoid);
	}

	@RequestMapping(value = "/id/{todoid}",method = RequestMethod.GET)
	public Optional<Todo> findbyid(@PathVariable Integer todoid) {
		return todoService.findId(todoid);
	}

	@ApiIgnore
	@RequestMapping(value = "/name/{todocategory}",method = RequestMethod.GET)
	public List<Todo> findbyname(@PathVariable int todoCategory)
	{
		return todoService.getTodoCategory(todoCategory);
	}
}
