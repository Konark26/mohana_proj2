package com.Relove.TodoList.todoList.service;

import com.Relove.TodoList.todoList.model.Todo;
import com.Relove.TodoList.todoList.repository.TodoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TodoService {
	@Autowired
	TodoRepository todoRepository;

	public List<Todo> getAllTodos(){

		return todoRepository.findAll();
	}

	public List<Todo> addTodo(Todo newitem){
		todoRepository.save(newitem);
		return todoRepository.findAll();
	}
	
	public void deleteTodo(Integer itemid){
		todoRepository.deleteById(itemid);
	}
	
	public Optional<Todo> findId(Integer itemid){
		
		return todoRepository.findById(itemid);
	}
	
	public List<Todo> getTodoCategory(int todoPriority){
		return todoRepository.findByTodoPriority (todoPriority);
	}
}

